# Prepare, submit and verify

Inspect the live application early: employer, requisition, account requirements, documents, knockout questions and duplicate status. Ask the candidate to handle password creation, verification codes or CAPTCHA when needed; continue independent preparation.

Follow explicit application-language requirements. Otherwise use candidate preferences and role context. Menu language alone does not establish working language.

Maintain a compact requirement-to-evidence matrix. Review as a recruiter (identity, relevance, level, clarity) and hiring manager (ownership, technical depth, impact). Preserve honest adjacency. Surface legal/credential incompatibility and unresolved required answers. A candidate-approved strategic stretch does not automatically halt preparation.

Fill routine fields from known facts. Do not invent birth dates, demographic traits, compensation, sponsorship, references or qualifications. Enter only the approved employer-specific salary; preserve fixed/bonus meaning. Avoid unnecessary optional disclosures.

Upload into the correct slots and verify filenames. Resume, cover letter and portfolio are distinct. Some portals reset unsaved fields after uploads: upload first when useful, then fill/save and verify again.

## Final checkpoint

Present the completed package: employer/role, actual files or preview, salary, material assumptions and unresolved issues. Finish checks before asking for final approval. On approval, submit the exact package without asking again for identical content after routine restoration. New employer, salary, substantive changes or binding answers require review.

## Fragile forms and retries

- Snapshots may omit visibly populated email/phone values. Inspect a fresh screenshot and legitimate read-only DOM field state where available. Blank extracted text alone does not prove either correctness or emptiness.
- Re-enter approved values through visible controls when uncertain, trigger normal blur/save behavior and verify. Never manufacture evidence or alter labels to persuade an approval reviewer.
- Follow automatic-review rejection reasons. Retry only after correction or adequate new evidence, never by switching to a hidden endpoint or another tool to bypass the block. If unresolved, explain and hand the action to the candidate.
- If a tab closes, check for saved/submitted state before reconstructing the same approved package.
- If submission times out, inspect receipts/status before retrying. Mark uncertain until confirmed; never resubmit merely to test success.

## Confirmation

Require explicit receipt/success text, verified submitted status or a relevant employer confirmation email. Generic welcomes, changed titles, application IDs and saved drafts alone may not establish submission. Account creation offered after an explicit receipt is separate from submission.

Record actual document versions, approved salary, timestamp, requisition, receipt and application ID. Preserve history. Do not duplicate confirmed submissions. If the candidate manually submits, verify and update the same entry. Never assign one role’s rejection or receipt to another role at the same employer.
