# RX Resume connection and tailoring

## Verify access

Confirm the candidate’s service URL, including self-hosted deployments. Consult that deployment’s current official API documentation before constructing requests; do not assume remembered endpoints or schemas.

Prefer documented API access for repeatable edits where available. Receive the API key through the host’s secure secret facility or a private local credential file. Never print it, include it in command logs, commit it or ship it in this skill. Send credentials only to the verified intended service origin, never a job-listing URL or unverified redirect.

Use the narrowest available authenticated identity/profile request. Do not export an entire account just to verify identity. Before writing, verify account identity, source resume ID, candidate name and contact details; repeat after account/session changes. A key filename or resume title is insufficient proof. Browser identity does not prove a separate API key belongs to that account.

For browser access, inspect the signed-in profile and resume contents. Stop writes if the account belongs to a family member or another person; let the candidate sign in correctly. Never edit unrelated resumes. If API identity cannot be established, use a separately verified browser session. Do not claim an API is connected until a scoped authenticated request succeeds.

## Preserve and tailor

Identify the candidate-approved master and design. Keep a private backup of that resume’s data when appropriate, then duplicate per employer/requisition/language. Preserve masters and private visibility.

Inspect the current schema/UI before editing. Tailor headline, summary, skills emphasis and selected bullets using confirmed facts. Preserve chronology and truthful titles. Do not add tools merely to match keywords.

Use RX’s cover-letter feature if the deployed version supports it. Otherwise create a matching local cover letter and clearly record that it is outside RX; do not pretend it was saved in the portal. Explain the employer connection with concrete evidence rather than generic enthusiasm.

Verify saved changes and export the actual final PDF. Retain editable source, IDs and versions. If a duplicate/create request times out, check for the intended copy before retrying; read a targeted resume after an uncertain update.

## Artifact checks

Inspect every rendered page and extract text from the exact final file. Check contacts, dates, employers, education, headings, reading order, file size, links, clipping and unsupported claims. A successful export or thumbnail is not sufficient.

Separate defects from heuristics. University names, abbreviations such as UX, German compounds and normal wrapping can trigger false positives. Review actual text, record the disposition and move on. Respect the candidate’s tolerance for ordinary wrapping; do not chase scores indefinitely.

Fix missing/garbled text, image-only exports, real broken words, clipping and materially misleading reading order. Two-column and untagged PDFs can behave differently across parsers. Report observable checks without guaranteeing ATS acceptance. Recheck after material changes, not repeatedly after stable results.
