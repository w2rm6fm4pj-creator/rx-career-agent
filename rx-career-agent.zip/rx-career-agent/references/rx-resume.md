# RX Resume connection and tailoring

## Guided first-time setup

Do not assume an RX account exists. Ask whether the candidate has one and guide registration on the verified official service one screen at a time. Let the candidate handle passwords, verification and terms. Check the signed-in identity, including when a family member previously used the browser. An empty account is valid; build the first draft only from confirmed candidate information.

Check current official connection documentation. Prefer a supported OAuth sign-in connection when available; use a documented API key or verified browser session otherwise. Do not promise that skill installation provides a connector. RX documents its MCP connection at https://docs.rxresu.me/guides/using-the-mcp-server and key creation at https://docs.rxresu.me/guides/using-the-api.

For key setup, guide Settings → API Keys → Create a new API key, with a descriptive label and expiry. Explain that the secret is shown once. Prefer supported secure credential storage. For a local-file-capable assistant, guide saving only the key in a private plain-text file outside the sharing repository, then ask for the path, not the value. Explain TextEdit's Make Plain Text option or Notepad when needed. Desktop can sync; prefer a private local folder. Do not ask for a key in chat, an ordinary attachment, screenshots or shared repository files. If local access is unavailable, use a supported connection or guide a browser workflow; a path alone does not grant cloud chat access.

Keep credentials out of tool outputs and model-visible logs. Confirm a scoped authenticated read before reporting connected. Verify identity separately for API and browser access. For an empty account where API identity cannot be established, use a verified browser session rather than infer ownership from the key filename. Explain how to revoke/replace lost or exposed keys without collecting the replacement in chat.

## Verify access

Confirm the candidate’s service URL, including self-hosted deployments. Consult that deployment’s current official API documentation before constructing requests; do not assume remembered endpoints or schemas.

Prefer documented API access for repeatable edits where available. Receive the API key through the host’s secure secret facility or a private local credential file. Never print it, include it in command logs, commit it or ship it in this skill. Send credentials only to the verified intended service origin, never a job-listing URL or unverified redirect.

Use the narrowest available authenticated identity/profile request. Do not export an entire account just to verify identity. Before writing, verify account identity, source resume ID, candidate name and contact details; repeat after account/session changes. A key filename or resume title is insufficient proof. Browser identity does not prove a separate API key belongs to that account.

For browser access, inspect the signed-in profile and resume contents. Stop writes if the account belongs to a family member or another person; let the candidate sign in correctly. Never edit unrelated resumes. If API identity cannot be established, use a separately verified browser session. Do not claim an API is connected until a scoped authenticated request succeeds.

## Preserve and tailor

Identify the candidate-approved master and design. Keep a private backup of that resume’s data when appropriate, then duplicate per employer/requisition/language. Preserve masters and private visibility.

Inspect the current schema/UI before editing. Tailor headline, summary, skills emphasis and selected bullets using confirmed facts. Preserve chronology and truthful titles. Do not add tools merely to match keywords.

Use RX’s cover-letter feature if the deployed version supports it. Otherwise create a matching local cover letter and clearly record that it is outside RX; do not pretend it was saved in the portal. Explain the employer connection with concrete evidence rather than generic enthusiasm.

Verify saved changes and export the actual final PDF. Retain editable source, IDs and versions. If a duplicate/create request times out, check for the intended copy before retrying; read a targeted resume after an uncertain update.

## Artifact checks

Inspect every rendered page and extract text from the exact final file. Check contacts, dates, employers, education, headings, reading order, file size, links, clipping and unsupported claims. A successful export or thumbnail is not sufficient.

Separate defects from heuristics. University names, abbreviations such as UX, German compounds and normal wrapping can trigger false positives. Review actual text, record the disposition and move on. Respect the candidate’s tolerance for ordinary wrapping; do not chase scores indefinitely.

Fix missing/garbled text, image-only exports, real broken words, clipping and materially misleading reading order. Two-column and untagged PDFs can behave differently across parsers. Report observable checks without guaranteeing ATS acceptance. Recheck after material changes, not repeatedly after stable results.
