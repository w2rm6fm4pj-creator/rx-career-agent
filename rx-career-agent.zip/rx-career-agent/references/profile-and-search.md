# Profile discovery and opportunity research

## Analyze before interviewing

Read the actual resume and supplied portfolio/work samples before asking questions. Preserve factual historical titles, employers and dates; use a functional headline to clarify positioning without rewriting history.

Summarize apparent strengths and consequential uncertainties. Ask two or three connected questions at a time, then adapt; avoid giant questionnaires and questions already answered in the source record.

Useful probes:

- What problem existed, what did you personally own, and what changed?
- Who used it? How many people were in scope versus actually adopting it?
- Was it a concept, prototype, production deployment, handoff or ongoing operation?
- Which tools did you implement, coordinate others using, or only evaluate?
- Was the result measured, estimated, informally observed or merely targeted?
- What were the team, stakeholders, budget and geographic scope?
- Which work would you seek or decline even if you could perform it?

Record sources and uncertainty for material claims. Use scope/action/outcome statements; omit unsupported numbers. Distinguish revenue influenced from owned, company size from team size, repository hosting from runtime deployment, and plans from implemented adoption.

Confirm target location, relocation, travel, office attendance, work authorization, languages, availability, employment type and compensation priorities. Travel willingness does not imply relocation or a second residence. An employer-specific attendance limit is not universal. Do not inherit another candidate’s country, salary floor, seniority or employer preferences.

Produce a short positioning brief and search criteria for candidate correction. Continue research independent of unanswered questions.

## Holistic discovery

Combine official employer boards, public listings, existing opportunities, company radar and relevant network records. Add LinkedIn feeds and job-alert emails only when connected and authorized. Email complements rather than replaces the search; read only job-related material in scope. Do not send outreach as a side effect.

Search responsibilities and adjacent role families as well as titles. Verify each recommended vacancy and its application route on official employer pages. Search-index visibility alone is not live verification. Keep anonymous recruiter leads conditional until identity and terms are known. Deduplicate employer/requisition/role/location against the ledger.

Grade **WANT before FIT**, separately out of ten:

- WANT: candidate interest, employer quality, work pattern, compensation, seniority, resources and career direction.
- FIT: direct evidence, transferable experience, required credentials, technical depth and gaps.

Explain reasons; scores are judgments, not offer probabilities. Unknown compensation or attendance stays unknown. Default to at most eight useful leads, fewer when warranted. Label new, previously known, submitted and unverified opportunities.

Classify must-haves as direct, adjacent, missing, mismatch or unknown. Distinguish mandatory credentials from preferred degrees and ambiguous implementation language. Missing terminology is not proof of inability; a prototype is not proof of senior production expertise. Investigate ambiguity and communicate credible stretches without either embellishment or reflexive discouragement.

## Compensation and learning

Use official pay ranges first, then credible employer/role/location comparators. Record dates, sample sizes, level differences and bonus inclusion. Distinguish a market estimate from an employer band. Thirteen or fourteen installments do not automatically increase annual fixed pay. Recommend an amount, then obtain employer-specific approval before entering it.

Track delivery, screening, interviews and offers. Do not diagnose ATS rejection from a generic rejection email. A demonstrated unreadable PDF is evidence of a file problem, not proof of an employer’s reasoning. Refine positioning using patterns and actual feedback.
