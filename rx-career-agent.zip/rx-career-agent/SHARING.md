# Share and use

Use START-HERE-DE.md for German. Start with the included START-HERE.md for beginner setup, including Codex and Claude installation, creating an RX account, and secure connection options. This package contains instructions, not credentials, personal history or a hosted service.

Keep candidate records and credentials in a separate private workspace. Full execution needs research, file/PDF tools, RX access and authenticated browser control. Where tools are missing, guide the manual step and state the limitation. Compensation and final submission remain candidate-approved.

Structure validation does not establish a live connection. Verify the recipient's account and a first draft before application work. The full Claude and fresh-user workflows remain untested.
