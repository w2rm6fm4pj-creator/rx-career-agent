# Share and use

This package contains instructions only: no resume, API key, account connection or personal history.

For Codex, place the whole `rx-career-agent` folder in the recipient’s skills directory (normally `~/.codex/skills/`, or the configured Codex home’s `skills/` directory). Start a new task so the skill is discovered. Other agents may support SKILL.md differently; use their installation process.

Suggested first message:

> Use $rx-career-agent to analyze my resume, interview me about my experience and goals, connect my own Reactive Resume account, and help me find and apply to suitable jobs.

The recipient supplies their own resume, RX account and API key or browser login. Full execution needs file/PDF tools, web research and authenticated browser control. RX API access does not grant employer-portal or email access. When capabilities are missing, the agent can prepare materials and guide the manual steps.

Keep all candidate data and credentials in a separate private workspace. Share only this folder or its ZIP. Salary choices and final submissions remain candidate-approved by default.

Validation checks package structure and workflow consistency; it does not establish a live API connection or guarantee employer submissions. Verify the recipient’s account and first resume duplicate before live application work.
